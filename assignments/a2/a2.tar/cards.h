#pragma once
#include <iostream>
#include <string>

using namespace std;

struct Card{
	string value;
	string suit;
};